package model;

public class FixedWordRepository extends WordRepository {

    
    public Word getWord() {

        return new Word("ligne");
    }
}
