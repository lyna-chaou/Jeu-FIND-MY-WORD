package model;

public abstract class WordRepository {

    public abstract Word getWord();

}

