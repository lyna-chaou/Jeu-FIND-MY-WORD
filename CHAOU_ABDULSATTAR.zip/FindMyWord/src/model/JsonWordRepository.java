package model;

import words.WordSet;
import words.JsonWordSet;

public class JsonWordRepository extends WordRepository {

    
    public Word getWord() {

        try {

            WordSet words = new JsonWordSet(
                "../wordset_bundle_etudiant/data/mots.json"
            );

            return new Word(words.random());

        } catch (Exception e) {

            return new Word("ligne");
        }
    }
}
