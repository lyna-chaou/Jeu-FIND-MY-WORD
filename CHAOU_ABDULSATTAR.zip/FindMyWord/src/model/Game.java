package model;

public class Game {

    private int essais;
    private Word motSecret;

    public Game() {
        essais = 0;

        WordRepository repository = new JsonWordRepository();

	motSecret = repository.getWord();
    }

    public void start() {

    }
    
    public void afficherMotSecret() {
    	System.out.println(motSecret.getValue());
    }
    
    public boolean estTrouve(String tentative) {
    	return motSecret.getValue().equals(tentative);
    }	
    
    public int getEssais() {
    	return essais;
   }
   
    public void ajouterEssai() {
    	essais++;
   } 
   
    public String getMotSecret() {
    	return motSecret.getValue();
   }
    
}
