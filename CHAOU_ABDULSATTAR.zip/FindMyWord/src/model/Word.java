package model;

public class Word {

    private String value;

    public Word(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }

    public boolean aCinqLettres() {
        return value.length() == 5;
    }

    public boolean contientSeulementDesLettres() {
        return value.matches("[a-zA-Z]+");
    }

    public boolean contientLettresRepetees() {

        for (int i = 0; i < value.length(); i++) {

            for (int j = i + 1; j < value.length(); j++) {

                if (value.charAt(i) == value.charAt(j)) {
                    return true;
                }

            }

        }

        return false;
    }

    public boolean estValide() {
        return aCinqLettres() && contientSeulementDesLettres();
    }
}
