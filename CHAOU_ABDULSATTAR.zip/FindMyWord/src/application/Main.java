package application;

import java.util.Scanner;
import model.Game;
import model.Word;

public class Main {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        Game jeu = new Game();

        System.out.println("");
        System.out.println("FIND MY WORD");
        System.out.println("");

        System.out.print("Entrez votre nom : ");
        String nom = scanner.nextLine();

        System.out.println("Bonjour " + nom);

        System.out.println("[ ][ ][ ][ ][ ]");
        
        boolean trouve = false;
	String[] historique = new String[6];
	String[] historiqueResultats = new String[6];
        

        for (int i = 1; i <= 6; i++) {

            System.out.print("Tentative " + i + " : ");

            String tentative = scanner.nextLine();

            Word motSaisi = new Word(tentative);
            

            if (!motSaisi.aCinqLettres()) {

                System.out.println("Erreur : le mot doit contenir exactement 5 lettres");
                
                i--;

            }

            else if (!motSaisi.contientSeulementDesLettres()) {

                System.out.println("Erreur : le mot doit contenir uniquement des lettres");
                
                i--;

            }
            
	    else if (motSaisi.contientLettresRepetees()) {

    		System.out.println("Erreur : le mot ne doit pas contenir de lettre répétée");
		i--; 
	    }
	    
            else {

                String motSecret = jeu.getMotSecret();
                
                jeu.ajouterEssai();
                
                historique[jeu.getEssais() - 1] = tentative;
                


		

                String resultat = "";

		for (int j = 0; j < 5; j++) {

    			char lettre = tentative.charAt(j);

    			if (lettre == motSecret.charAt(j)) {
        			resultat += "OK ";
    			}

    			else if (motSecret.contains("" + lettre)) {
        			resultat += "PRESENT ";
    			}

    			else {
        			resultat += "ABSENT ";
    			}
		}

		historiqueResultats[jeu.getEssais() - 1] = resultat;

		for (int k = 0; k < jeu.getEssais(); k++) {

    			String mot = historique[k];

    			for (int l = 0; l < 5; l++) {
        			System.out.print("[ " + Character.toUpperCase(mot.charAt(l)) + " ]");
    			}

    			System.out.print(" -> ");

    			System.out.println(historiqueResultats[k]);
	}

	System.out.println();

                    if (jeu.estTrouve(tentative)) {
                    	System.out.println("Bravo !");
			System.out.println("Vous avez trouvé le mot en " + jeu.getEssais() + " essai(s).");
                    	trouve = true;
                    	break;
                }
            }
        }

        if (!trouve) {
            System.out.println("Vous avez utilisé tous vos essais.");
	    System.out.println("Partie perdue.");
	    System.out.println("Le mot était : " + jeu.getMotSecret());
        }
    }
}
