package application;

import model.Game;
import model.Word;
import model.WordRepository;
import model.JsonWordRepository;

public class Test {

    public static void main(String[] args) {

        System.out.println("TEST WORD");

        Word mot = new Word("table");

        System.out.println("Mot : " + mot.getValue());
        System.out.println("5 lettres : " + mot.aCinqLettres());
        System.out.println("Seulement des lettres : " + mot.contientSeulementDesLettres());
        System.out.println("Valide : " + mot.estValide());

        Word mot2 = new Word("belle");

        System.out.println("Lettres répétées : " + mot2.contientLettresRepetees());

        System.out.println();

        System.out.println("TEST REPOSITORY");

        WordRepository repository = new JsonWordRepository();

        System.out.println("Mot récupéré : " + repository.getWord().getValue());

        System.out.println();

        System.out.println("TEST GAME");

        Game jeu = new Game();

        System.out.println("Mot secret : " + jeu.getMotSecret());

        System.out.println("Essais avant : " + jeu.getEssais());

        jeu.ajouterEssai();

        System.out.println("Essais après : " + jeu.getEssais());

        System.out.println("Mot trouvé : " + jeu.estTrouve(jeu.getMotSecret()));

        System.out.print("Affichage du mot secret : ");
        jeu.afficherMotSecret();

        System.out.println("Tests terminés.");
    }
}
